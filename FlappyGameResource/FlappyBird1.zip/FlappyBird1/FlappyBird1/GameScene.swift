 //
//  GameScene.swift
//  FlappyBird1
//
//  Created by Yuta Fujii on 2018/02/02.
//  Copyright © 2018年 Yuta Fujii. All rights reserved.
//

import SpriteKit
import GameplayKit

class GameScene: SKScene,SKPhysicsContactDelegate {
    
    var bird = SKSpriteNode()
    var gameOverImage = SKSpriteNode()
    let jumpSound = SKAction.playSoundFileNamed("sound.mp3", waitForCompletion:false)
    let backSound = SKAction.playSoundFileNamed("backSound.mp3", waitForCompletion:false)
    
    var blockingObjects = SKNode()
    
    var score = Int(0)
    var scoreLbl = SKLabelNode()
    var pipeTop = SKSpriteNode()
    
    var timer:Timer = Timer()
    var gameTimer:Timer = Timer()
    
    var timeString = String()
    
    override func didMove(to view: SKView) {
    
        self.run(backSound, withKey: "backSound")
        self.run(jumpSound, withKey: "jumpSound")
        createParts()
    }
    
    func createParts(){
        
        let backView = SKSpriteNode(imageNamed: "bg.png")
        backView.position = CGPoint(x: 0, y: 0)
        backView.run(SKAction.repeatForever(SKAction.sequence([
            
                SKAction.moveTo(x: -self.size.width, duration: 13.0),
                SKAction.moveTo(y: 0, duration: 0.0)
            
            ])))
        
        self.addChild(backView)
        
        let backView2 = SKSpriteNode(imageNamed: "bg.png")
        backView2.position = CGPoint(x: self.frame.width, y: 0)
        backView2.run(SKAction.repeatForever(SKAction.sequence([
            
            SKAction.moveTo(x: 0, duration: 13.0),
            SKAction.moveTo(y: self.frame.width, duration: 0.0)
            
            ])))

        
        self.addChild(backView2)
        
        bird = SKSpriteNode()
        gameOverImage = SKSpriteNode()
        blockingObjects = SKSpriteNode()
        
        
        score = Int(0)
        scoreLbl = SKLabelNode()
        scoreLbl = self.childNode(withName: "scoreLbl") as! SKLabelNode
        scoreLbl.text = "\(score)"
        scoreLbl.color = UIColor.white
        scoreLbl.zPosition = 14
        scoreLbl.fontSize = 50
        scoreLbl.fontName = "HelveticaNeue-Bold"
        
        let scoreBg = SKShapeNode()
        scoreBg.position = CGPoint(x: 0, y: 0)
        scoreBg.path = CGPath(roundedRect: CGRect(x: CGFloat(-50), y: CGFloat(-30), width: CGFloat(100), height: CGFloat(100)), cornerWidth: 50, cornerHeight: 50, transform: nil)
        let scoreBgColor = UIColor.gray
        scoreBg.alpha = 0.5
        scoreBg.strokeColor = UIColor.clear
        scoreBg.fillColor = scoreBgColor
        scoreBg.zPosition = 13
        scoreLbl.addChild(scoreBg)
        
        
        
        timer = Timer()
        gameTimer = Timer()
        
        self.physicsWorld.contactDelegate = self
        self.physicsWorld.gravity = CGVector(dx: 0, dy: -6)
        
        blockingObjects.removeAllChildren()
        gameOverImage = SKSpriteNode()
        self.addChild(blockingObjects)
        
        
        let gameOverTexture = SKTexture(imageNamed: "GameOverImage.jpg")
        gameOverImage = SKSpriteNode(texture: gameOverTexture)
        gameOverImage.position = CGPoint(x: self.frame.midX, y: self.frame.midY)
        gameOverImage.zPosition = 11
        self.addChild(gameOverImage)
        gameOverImage.isHidden = true
        
        let birdTexture = SKTexture(imageNamed: "bird.png")
        bird = SKSpriteNode(texture: birdTexture)
        bird.position = CGPoint(x: self.frame.midX, y: self.frame.midY)
        
        bird.physicsBody = SKPhysicsBody(circleOfRadius: bird.size.height/2)
        bird.physicsBody?.isDynamic = true
        bird.physicsBody?.allowsRotation = false
        
        bird.physicsBody?.categoryBitMask = 1
        
        bird.physicsBody?.collisionBitMask = 2
        bird.physicsBody?.contactTestBitMask = 2
        
        bird.zPosition = 10
        
        self.addChild(bird)
        
        
        let ground = SKNode()
        ground.position = CGPoint(x: -325, y: -700)
        
        ground.physicsBody = SKPhysicsBody(rectangleOf: CGSize(width: self.frame.size.width, height: 1))
        
        ground.physicsBody?.isDynamic = false
        
        ground.physicsBody?.categoryBitMask = 2
        blockingObjects.addChild(ground)
        
        timer = Timer.scheduledTimer(timeInterval: 4, target: self, selector: #selector(createPipe), userInfo: nil, repeats: true)
        
        gameTimer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(updateScore), userInfo: nil, repeats: true)
        
    }

    @objc func updateScore(){
        
        score += 1
        scoreLbl.text = "\(score)"
        
    }

    
    @objc func createPipe(){
        
        //パイプ生成
        let randamLength = arc4random() % UInt32(self.frame.size.height/2)
        let offset = CGFloat(randamLength) - self.frame.size.height/4
        let gap = bird.size.height*3
        let pipeTopTexture = SKTexture(imageNamed: "pipeTop.png")
        pipeTop = SKSpriteNode(texture: pipeTopTexture)
        pipeTop.position = CGPoint(x: self.frame.midX + self.frame.width/2, y: self.frame.midY + pipeTop.size.height/2 + gap/2 + offset)
        pipeTop.physicsBody = SKPhysicsBody(rectangleOf: pipeTop.size)
        pipeTop.physicsBody?.isDynamic = false
        
        pipeTop.physicsBody?.categoryBitMask = 2
        blockingObjects.addChild(pipeTop)
        
        
        
        //下のパイプ
        let  pipeBottomTexture = SKTexture(imageNamed: "pipeBottom.png")
        let pipeBottom = SKSpriteNode(texture: pipeBottomTexture)
        pipeBottom.position = CGPoint(x: self.frame.midX + self.frame.width/2, y: self.frame.midY - pipeBottom.size.height/2 - gap/2 + offset)
        pipeBottom.physicsBody = SKPhysicsBody(rectangleOf: pipeBottom.size)
        pipeBottom.physicsBody?.isDynamic = false
        
        pipeBottom.physicsBody?.categoryBitMask = 2
        blockingObjects.addChild(pipeBottom)
        
        let pipeMove = SKAction.moveBy(x: -self.frame.size.width - 70, y: 0, duration: 4)
        pipeTop.run(pipeMove)
        pipeBottom.run(pipeMove)
    
    }
    
    
    
    func didBegin(_ contact: SKPhysicsContact) {
        
        blockingObjects.speed = 0
        gameOverImage.isHidden = false
        timer.invalidate()
        gameTimer.invalidate()
        score = 0
        scoreLbl.removeAllChildren()
        blockingObjects.removeAllActions()
        blockingObjects.removeAllChildren()
        
        let ud = UserDefaults.standard
        self.timeString = ud.object(forKey: "saveData") as! String
        
        if Int(self.timeString)! < Int(scoreLbl.text!)!{
           
            ud.set(scoreLbl.text!, forKey: "saveData")
            
        }
        
        self.removeAction(forKey: "backSound")
        self.removeAction(forKey: "jumpSound")

    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        
        if gameOverImage.isHidden == false{
            
            gameOverImage.isHidden = true
            bird.removeFromParent()
            createParts()
        }else{
            
            bird.physicsBody?.velocity = CGVector(dx: 0, dy: 0)
            bird.physicsBody?.applyImpulse(CGVector(dx: 0, dy: 500))
            run(jumpSound)
        
        }
        
    }
    
    
    
    
    
    override func update(_ currentTime: TimeInterval) {
        // Called before each frame is rendered
    }
}
